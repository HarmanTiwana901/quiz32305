//
//  Adopt.swift
//  quiz3
//
//  Created by Jessie sihota on 2022-05-30.
//

import Foundation
import SwiftUI

struct Adopt: View {
    // reference: https://serialcoder.dev/text-tutorials/swiftui/creating-grids-in-swiftui/
    let columns = [GridItem(.fixed(120), spacing: 0),
                   GridItem(.fixed(120), spacing: 0),
                   GridItem(.fixed(120), spacing: 0)]
    
    // object
    @State var isClicked = false

    
    var body: some View {
        VStack {
            Text("Adopt an Iguana")
                .font(.system(size: 34))
                .bold()
        
            ScrollView {
                    LazyVGrid(columns: columns) {
                        ForEach((0...14), id: \.self) { _ in
                            VStack {
                                Button {
                                    guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else {
                                        return
                                    }
                                    let task = URLSession.shared.dataTask(with: url) {
                                        data, response, error in
                                        
                                        let decoder = JSONDecoder()
                                        
                                        if let data = data {
                                            do {
                                                let pets = try decoder.decode([Iguana].self, from: data)
                                                pets.forEach{i in
                                                    print(i.username)}
                                            } catch {
                                                print(error)    
                                            }
                                        }
                                    }
                                    task.resume()
                                    print("Clicked")
                                } label: {
                                    Image("iguana")
                                        .padding(5)
                                }.sheet(isPresented: $isClicked) {
                                    Confirm()
                                }
                                Text("Iguana See ID")
                                    .bold()
                            }
                        }
                    }
                }
            
            
        }
    }
}

struct Adopt_Previews: PreviewProvider {
    static var previews: some View {
        Adopt()
    }
}
