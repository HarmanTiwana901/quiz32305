//
//  Confirm.swift
//  quiz3
//
//  Created by Jessie sihota on 2022-05-30.
//
import SwiftUI

struct Confirm: View {
    // reference: https://serialcoder.dev/text-tutorials/swiftui/creating-grids-in-swiftui/
    let columns = [GridItem(.fixed(120), spacing: 0),
                   GridItem(.fixed(120), spacing: 0),
                   GridItem(.fixed(120), spacing: 0)]
    
    // object
    @State var isClicked = false

    
    var body: some View {
        VStack {
            Text("Adopt an Iguana")
                .font(.system(size: 34))
                .bold()
        
            ScrollView {
                    LazyVGrid(columns: columns) {
                        ForEach((0...14), id: \.self) { _ in
                            VStack {
                                Button {
                                    print("Clicked")
                                } label: {
                                    Image("iguana")
                                        .padding(5)
                                }.sheet(isPresented: $isClicked) {
                                    Confirm()
                                }
                                Text("Iguana See ID")
                                    .bold()
                            }
                        }
                    }
                }
        }
    }
}

struct Confirm_Previews: PreviewProvider {
    static var previews: some View {
        Adopt()
    }
}
