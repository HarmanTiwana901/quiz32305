//
//  quiz3App.swift
//  quiz3
//
//  Created by Jessie sihota on 2022-05-30.
//

import SwiftUI

@main
struct quiz3App: App {
    var body: some Scene {
        WindowGroup {
            Adopt()
        }
    }
}
