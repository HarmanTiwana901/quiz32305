//
//  Iguana.swift
//  quiz3
//
//  Created by Jessie sihota on 2022-05-30.
//

import Foundation

struct Iguana: Decodable {
    var username: String
    var email: String
    var address: String
}

